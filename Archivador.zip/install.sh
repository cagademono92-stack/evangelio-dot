#!/usr/bin/env bash
#
# install.sh — instalación automática de yay + dependencias + config.
#
# Uso:
#   1) Descomprimí tu Archivador.zip
#   2) Dejá este install.sh en la MISMA carpeta que quedó al descomprimir
#      (o sea: al lado de "hypr", "waybar", "rofi", "swaync", "waypaper",
#      "matugen", etc.)
#   3) chmod +x install.sh && ./install.sh
#
# A diferencia de la versión anterior, este script NO tiene hardcodeada la
# lista de carpetas — copia automáticamente TODAS las carpetas que
# encuentre al lado suyo. Así no hay que volver a editarlo cada vez que
# cambia la estructura del zip.
#
# Nota sobre ext4: esto no requiere nada especial por el sistema de
# archivos — cp/mv funcionan igual en ext4 que en cualquier otro FS de
# Linux, así que el script no hace ninguna distinción ahí.

set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
CONFIG_DIR="$HOME/.config"
BACKUP_DIR="$HOME/.config-backup-$(date +%Y%m%d_%H%M%S)"

echo "=== 1/4: Verificando yay ==="
if ! command -v yay &>/dev/null; then
	echo "yay no está instalado. Instalando desde AUR..."
	sudo pacman -S --needed --noconfirm git base-devel
	tmpdir=$(mktemp -d)
	git clone https://aur.archlinux.org/yay.git "$tmpdir/yay"
	(cd "$tmpdir/yay" && makepkg -si --noconfirm)
	rm -rf "$tmpdir"
else
	echo "yay ya está instalado, salteando."
fi

echo ""
echo "=== 2/4: Instalando dependencias ==="
# Lo que pediste explícitamente:
CORE_PKGS=(waybar rofi swaync)
# Lo que tu config ya usa y necesita para no romperse (hyprpaper/matugen para
# el theming dinámico, waypaper como picker de wallpapers, y el resto de
# binds/scripts que armamos):
EXTRA_PKGS=(
	hyprpaper
	matugen
	waypaper
	nwg-bar
	wf-recorder
	wvkbd
	hyprpicker
	hyprshot
	cliphist
	playerctl
	brightnessctl
	grim
	slurp
	jq
	fuzzel
)

echo "Paquetes principales: ${CORE_PKGS[*]}"
echo "Dependencias extra:   ${EXTRA_PKGS[*]}"
read -rp "¿Instalar todo esto con yay? [S/n] " confirm
if [[ "$confirm" =~ ^[Nn]$ ]]; then
	echo "Instalación de paquetes cancelada. Seguimos solo con la copia de config."
else
	yay -S --needed --noconfirm "${CORE_PKGS[@]}" "${EXTRA_PKGS[@]}"
fi

echo ""
echo "=== 3/4: Detectando carpetas de config junto a este script ==="
FOLDERS=()
for entry in "$SCRIPT_DIR"/*/; do
	[ -d "$entry" ] || continue
	name="$(basename "$entry")"
	FOLDERS+=("$name")
done

if [ ${#FOLDERS[@]} -eq 0 ]; then
	echo "No encontré ninguna carpeta al lado de install.sh. ¿Lo dejaste junto a hypr/, waybar/, etc.?"
	exit 1
fi

echo "Carpetas encontradas: ${FOLDERS[*]}"

echo ""
echo "=== Backup de tu ~/.config actual ==="
mkdir -p "$BACKUP_DIR"
for dir in "${FOLDERS[@]}"; do
	if [ -d "$CONFIG_DIR/$dir" ]; then
		echo "Backup: $CONFIG_DIR/$dir -> $BACKUP_DIR/$dir"
		cp -r "$CONFIG_DIR/$dir" "$BACKUP_DIR/$dir"
	fi
done
echo "Backup completo en: $BACKUP_DIR"

echo ""
echo "=== 4/4: Copiando la config nueva a ~/.config ==="
for dir in "${FOLDERS[@]}"; do
	mkdir -p "$CONFIG_DIR/$dir"
	cp -r "$SCRIPT_DIR/$dir/." "$CONFIG_DIR/$dir/"
	echo "Copiado: $dir/ -> $CONFIG_DIR/$dir/"
done

# Permisos de ejecución para todos los scripts propios (donde sea que estén)
find "$CONFIG_DIR" -maxdepth 4 -type f -name "*.sh" -exec chmod +x {} \; 2>/dev/null || true

echo ""
echo "=========================================="
echo " Listo. Backup de tu config anterior en:"
echo "   $BACKUP_DIR"
echo ""
echo " Antes de recargar Hyprland:"
echo " 1. Editá ~/.config/hypr/hyprpaper.conf y poné la ruta real de tu"
echo "    wallpaper (si todavía apunta a un archivo de ejemplo)."
echo " 2. Corré: ~/.config/hypr/hyprland/scripts/wallpaper.sh ~/Pictures/wallpapers/tu-wallpaper.jpg"
echo "    para setear el wallpaper y generar los colores por primera vez."
echo " 3. hyprctl reload"
echo "=========================================="
