if status is-interactive
    # Commands to run in interactive sessions can go here
    starship init fish | source
end

# opencode
fish_add_path /home/receck/.opencode/bin
