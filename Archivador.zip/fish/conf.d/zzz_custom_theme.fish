# Generado por matugen — NO editar a mano, se sobreescribe con cada wallpaper
set --global fish_color_command       ffb3ae --bold
set --global fish_color_param         e1c28c
set --global fish_color_option        e1c28c
set --global fish_color_keyword       ffb3ae --bold
set --global fish_color_quote         e7bdb9
set --global fish_color_redirection   e1c28c --bold
set --global fish_color_operator      e1c28c
set --global fish_color_escape        e1c28c
set --global fish_color_end           e1c28c

set --global fish_color_error         ffb4ab --bold
set --global fish_color_status        ffb4ab
set --global fish_color_cwd           ffb3ae --bold
set --global fish_color_cwd_root      ffb4ab --bold
set --global fish_color_user          ffb3ae
set --global fish_color_host          normal
set --global fish_color_host_remote   e1c28c

set --global fish_color_comment        a08c8a
set --global fish_color_autosuggestion a08c8a

set --global fish_color_selection      white --bold --background=534342
set --global fish_color_search_match   --background=534342
set --global fish_color_valid_path     --underline

set --global fish_pager_color_completion          normal
set --global fish_pager_color_description         e7bdb9 yellow -i
set --global fish_pager_color_prefix              e1c28c --bold --underline
set --global fish_pager_color_progress            white --background=ffb3ae
set --global fish_pager_color_selected_background -r
