# Generado por matugen — NO editar a mano, se sobreescribe con cada wallpaper
set --global fish_color_command       ffb595 --bold
set --global fish_color_param         d2c78f
set --global fish_color_option        d2c78f
set --global fish_color_keyword       ffb595 --bold
set --global fish_color_quote         e6bead
set --global fish_color_redirection   d2c78f --bold
set --global fish_color_operator      d2c78f
set --global fish_color_escape        d2c78f
set --global fish_color_end           d2c78f

set --global fish_color_error         ffb4ab --bold
set --global fish_color_status        ffb4ab
set --global fish_color_cwd           ffb595 --bold
set --global fish_color_cwd_root      ffb4ab --bold
set --global fish_color_user          ffb595
set --global fish_color_host          normal
set --global fish_color_host_remote   d2c78f

set --global fish_color_comment        a08d85
set --global fish_color_autosuggestion a08d85

set --global fish_color_selection      white --bold --background=52443d
set --global fish_color_search_match   --background=52443d
set --global fish_color_valid_path     --underline

set --global fish_pager_color_completion          normal
set --global fish_pager_color_description         e6bead yellow -i
set --global fish_pager_color_prefix              d2c78f --bold --underline
set --global fish_pager_color_progress            white --background=ffb595
set --global fish_pager_color_selected_background -r
