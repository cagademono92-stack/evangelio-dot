# Generado por matugen — NO editar a mano, se sobreescribe con cada wallpaper
set --global fish_color_command       {{colors.primary.default.hex_stripped}} --bold
set --global fish_color_param         {{colors.tertiary.default.hex_stripped}}
set --global fish_color_option        {{colors.tertiary.default.hex_stripped}}
set --global fish_color_keyword       {{colors.primary.default.hex_stripped}} --bold
set --global fish_color_quote         {{colors.secondary.default.hex_stripped}}
set --global fish_color_redirection   {{colors.tertiary.default.hex_stripped}} --bold
set --global fish_color_operator      {{colors.tertiary.default.hex_stripped}}
set --global fish_color_escape        {{colors.tertiary.default.hex_stripped}}
set --global fish_color_end           {{colors.tertiary.default.hex_stripped}}

set --global fish_color_error         {{colors.error.default.hex_stripped}} --bold
set --global fish_color_status        {{colors.error.default.hex_stripped}}
set --global fish_color_cwd           {{colors.primary.default.hex_stripped}} --bold
set --global fish_color_cwd_root      {{colors.error.default.hex_stripped}} --bold
set --global fish_color_user          {{colors.primary.default.hex_stripped}}
set --global fish_color_host          normal
set --global fish_color_host_remote   {{colors.tertiary.default.hex_stripped}}

set --global fish_color_comment        {{colors.outline.default.hex_stripped}}
set --global fish_color_autosuggestion {{colors.outline.default.hex_stripped}}

set --global fish_color_selection      white --bold --background={{colors.surface_variant.default.hex_stripped}}
set --global fish_color_search_match   --background={{colors.surface_variant.default.hex_stripped}}
set --global fish_color_valid_path     --underline

set --global fish_pager_color_completion          normal
set --global fish_pager_color_description         {{colors.secondary.default.hex_stripped}} yellow -i
set --global fish_pager_color_prefix              {{colors.tertiary.default.hex_stripped}} --bold --underline
set --global fish_pager_color_progress            white --background={{colors.primary.default.hex_stripped}}
set --global fish_pager_color_selected_background -r
