#!/usr/bin/env bash
#
# wallpaper.sh — setea un wallpaper vía hyprpaper y regenera los colores
# de waybar/rofi/fish con matugen.
#
# Uso:
#   wallpaper.sh /ruta/a/imagen.png   -> usa esa imagen puntual
#   wallpaper.sh                      -> elige una al azar de WALLPAPER_DIR
#
# Requiere: hyprpaper, matugen (yay -S hyprpaper matugen)

WALLPAPER_DIR="$HOME/Pictures/wallpapers"

if [ -n "$1" ]; then
	WALLPAPER="$1"
else
	WALLPAPER=$(find "$WALLPAPER_DIR" -type f \( -iname "*.jpg" -o -iname "*.jpeg" -o -iname "*.png" \) | shuf -n 1)
fi

if [ -z "$WALLPAPER" ]; then
	notify-send "Wallpaper" "No encontré ninguna imagen en $WALLPAPER_DIR" -a "Hyprland"
	exit 1
fi

if ! command -v hyprctl &>/dev/null; then
	notify-send "Wallpaper" "hyprctl no está disponible" -a "Hyprland"
	exit 1
fi

if ! pgrep -x hyprpaper > /dev/null; then
	notify-send "Wallpaper" "hyprpaper no está corriendo, lo arranco..." -a "Hyprland"
	hyprpaper &
	sleep 1
fi

# Tu versión de hyprpaper simplificó la IPC a un solo request: "wallpaper",
# con argumentos [mon],[path],[fit_mode]. Ya no existen preload/unload como
# requests separados (por eso tirabas "invalid hyprpaper request" antes).
hyprctl hyprpaper wallpaper ",$WALLPAPER"

# Regenerar colores de waybar/rofi/fish a partir de esta imagen.
# --source-color-index 0 = usar el color más dominante automáticamente,
# sin mostrar el prompt interactivo que te colgaba el script antes.
if command -v matugen &>/dev/null; then
	matugen image "$WALLPAPER" --source-color-index 0
else
	notify-send "Wallpaper" "Cambiado, pero matugen no está instalado (sin recoloreo)" -a "Hyprland"
	exit 0
fi

notify-send "Wallpaper" "Cambiado y recoloreado" -a "Hyprland"
