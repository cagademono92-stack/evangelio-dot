-- Generado por matugen — NO editar a mano, se sobreescribe con cada wallpaper
hl.config({
    general = {
        col = {
            active_border   = "rgba(ffb3aeFF)",
            inactive_border = "rgba(53434266)",
        },
    },
    misc = {
        background_color = "rgba(1a1111FF)",
    },
})

hl.window_rule({
    match        = { pin = 1 },
    border_color = "rgba(ffb4abAA) rgba(e1c28c77)",
})