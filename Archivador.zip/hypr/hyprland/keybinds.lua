require("hyprland.lib")
require("hyprland.variables")
if is_file_exists(HOME .. "/.config/hypr/custom/variables.lua") then
	require("custom.variables")
end

local hyprScripts = "$HOME/.config/hypr/hyprland/scripts"

-- Modo "wallpaper" integrado como modi de rofi (script mode, rofi-script(5)).
-- El separator "#" evita que Hyprland parta el comando por las comas.
local rofiWallpaperMode = "wallpaper:" .. hyprScripts .. "/RofiWallpaperMode.sh"
-- Launcher principal con todos los modos (drun por defecto)
local rofiLauncher = 'rofi -show drun -modi "drun#run#filebrowser#' .. rofiWallpaperMode .. '"'
-- Picker de wallpaper directo con miniaturas en cuadrícula
local rofiWallpaperPicker = 'rofi -show wallpaper -modi "drun#' .. rofiWallpaperMode ..
	'" -theme-str \'listview { columns: 4; lines: 2; spacing: 12px; layout: vertical; fixed-columns: true; } element { orientation: vertical; padding: 12px; } element-icon { size: 9em; margin: 6px 0px 2px 0px; } element-text { horizontal-align: 0.5; }\''

-- Antes acá se chequeaba si Quickshell estaba vivo (qsIsAlive) para decidir
-- si usar sus funciones o caer a un fallback. Como ya no usamos Quickshell,
-- dejamos esta variable siempre en "false" para que TODOS los binds de abajo
-- que hacían "qsIsAlive || comando_de_respaldo" sigan funcionando igual,
-- sin tener que tocar cada línea una por una.
local qsIsAlive = "false"

hl.bind("SUPER + SUPER_L", hl.dsp.exec_cmd(qsIsAlive .. " || pkill rofi || " .. rofiLauncher), { description = "App: Launcher (Rofi)" })
hl.bind("SUPER + SUPER_R", hl.dsp.exec_cmd(qsIsAlive .. " || pkill rofi || " .. rofiLauncher))

-- [removido] SUPER_L/R workspaceNumber: overlay de Quickshell que mostraba el
-- número de escritorio al mantener SUPER. No hay equivalente nativo en
-- Hyprland sin Quickshell.

-- [removido] SUPER+Tab overviewWorkspacesToggle: overview de Quickshell.
-- Alternativa real: plugin hyprexpo (ver comentario en general.lua).

-- [removido] SUPER+V overviewClipboardToggle y SUPER+Period overviewEmojiToggle:
-- eran duplicados de los binds de portapapeles/emoji que ya están más abajo
-- con fallback funcional (cliphist+fuzzel / fuzzel-emoji.sh).

-- [removido] SUPER+A / SUPER+ALT+A / SUPER+B / SUPER+O sidebarLeftToggle(Detach):
-- sidebar izquierdo de Quickshell, sin reemplazo directo.

-- Notificaciones: reemplazado por swaync (nuestro centro de notificaciones real)
hl.bind("SUPER + N", hl.dsp.exec_cmd("swaync-client -t -sw"), { description = "Shell: Toggle notification center" })

-- [removido] SUPER+Slash cheatsheetToggle: sin reemplazo.

-- On-screen keyboard: requiere tener wvkbd instalado (yay -S wvkbd)
hl.bind("SUPER + K", hl.dsp.exec_cmd("pkill wvkbd-mobintl || wvkbd-mobintl"), { description = "Utilities: Toggle on-screen keyboard" })

-- Controles de medios: reusamos el widget mpris de swaync en vez del popup de Quickshell
hl.bind("SUPER + M", hl.dsp.exec_cmd("swaync-client -t -sw"), { description = "Media: Toggle media controls" })

-- [removido] SUPER+G overlayToggle: overlay de widgets de Quickshell, sin reemplazo.

-- Menú de sesión/power: nwg-bar en vez del session menu de Quickshell
hl.bind("CTRL + ALT + Delete", hl.dsp.exec_cmd("pkill nwg-bar || nwg-bar"), { description = "Session: Power menu" })

-- [removido] SHIFT+SUPER+ALT+Slash welcome.qml: pantalla de bienvenida de Quickshell.

hl.bind(
	"XF86MonBrightnessUp",
	hl.dsp.exec_cmd("brightnessctl s 5%+"),
	{ locked = true, repeating = true }
)
hl.bind(
	"XF86MonBrightnessDown",
	hl.dsp.exec_cmd("brightnessctl s 5%-"),
	{ locked = true, repeating = true }
)
hl.bind(
	"XF86AudioRaiseVolume",
	hl.dsp.exec_cmd("wpctl set-volume @DEFAULT_AUDIO_SINK@ 2%+ -l 1.5"),
	{ locked = true, repeating = true }
)
hl.bind(
	"XF86AudioLowerVolume",
	hl.dsp.exec_cmd("wpctl set-volume @DEFAULT_AUDIO_SINK@ 2%-"),
	{ locked = true, repeating = true }
)

-- Cambiar wallpaper: modo rofi integrado (miniatura en cuadrícula).
hl.bind(
	"CTRL + SUPER + T",
	hl.dsp.exec_cmd(qsIsAlive .. " || pkill rofi || " .. rofiWallpaperPicker),
	{ description = "Shell: Change wallpaper (rofi)" }
)
-- Wallpaper al azar + recoloreo automático (script propio, con hyprpaper + matugen)
hl.bind(
	"CTRL + SUPER + ALT + T",
	hl.dsp.exec_cmd(hyprScripts .. "/wallpaper.sh"),
	{ description = "Shell: Random wallpaper" }
)

-- [removido] CTRL+SUPER+SHIFT+D toggleLightDark: motor de temas claro/oscuro
-- de Quickshell (Material You), sin equivalente en el setup actual.

-- Reiniciar los componentes del "shell" (ahora: waybar + swaync, no Quickshell)
hl.bind(
	"CTRL + SUPER + R",
	hl.dsp.exec_cmd("killall waybar swaync; waybar & swaync &"),
	{ description = "Shell: Restart bar/notifications" }
)

-- [removido] CTRL+SUPER+P panelFamilyCycle: exclusivo de Quickshell.

--##! Utilities
--# Screenshot, Record, OCR, Color picker, Clipboard history
hl.bind(
	"SUPER + V",
	hl.dsp.exec_cmd(
		qsIsAlive .. " || pkill fuzzel || cliphist list | fuzzel --match-mode fzf --dmenu | cliphist decode | wl-copy"
	),
	{ description = "Utilities: Clipboard history >> clipboard" }
)
hl.bind(
	"SUPER + Period",
	hl.dsp.exec_cmd(qsIsAlive .. " || pkill fuzzel || " .. hyprScripts .. "/fuzzel-emoji.sh copy"),
	{ description = "Utilities: Emoji >> clipboard" }
)
hl.bind(
	"SUPER + SHIFT + S",
	hl.dsp.exec_cmd(qsIsAlive .. " || pidof slurp || hyprshot --freeze --clipboard-only --mode region --silent"),
	{ description = "Utilities: Screen snip" }
)
hl.bind("SUPER + SHIFT + A", hl.dsp.exec_cmd(qsIsAlive .. " || pidof slurp || " .. hyprScripts .. "/snip_to_search.sh"), { description = "Utilities: Google Lens" })
--# OCR
hl.bind(
	"SUPER + SHIFT + X",
	hl.dsp.exec_cmd(
		qsIsAlive
			.. " || pidof slurp || grim -g \"$(slurp $SLURP_ARGS)\" \"/tmp/ocr_image.png\" && tesseract \"/tmp/ocr_image.png\" stdout -l $(tesseract --list-langs | awk 'NR>1{print $1}' | tr '\\\\n' '+' | sed 's/\\\\+$/\\\\n/') | wl-copy && rm \"/tmp/ocr_image.png\""
	),
	{ description = "Utilities: Character recognition >> clipboard" }
)
-- [removido] SUPER+SHIFT+T screenTranslate: sin equivalente sin Quickshell.

--# Color picker
hl.bind(
	"SUPER + SHIFT + C",
	hl.dsp.exec_cmd("hyprpicker -a"),
	{ description = "Utilities: Pick color #RRGGBB >> clipboard" }
)

--# Grabación de pantalla — reemplazado por wf-recorder (yay -S wf-recorder)
-- Toggle: si ya está grabando, la corta (SIGINT le hace terminar el archivo bien).
hl.bind(
	"SUPER + SHIFT + R",
	hl.dsp.exec_cmd(
		"pkill --signal SIGINT wf-recorder || wf-recorder -g \"$(slurp)\" -f " ..
		"$(xdg-user-dir VIDEOS)/recording_$(date +%Y-%m-%d_%H.%M.%S).mp4"
	),
	{ locked = true, description = "Utilities: Record region (no sound)" }
)
hl.bind(
	"SUPER + ALT + R",
	hl.dsp.exec_cmd(
		"pkill --signal SIGINT wf-recorder || wf-recorder -g \"$(slurp)\" -f " ..
		"$(xdg-user-dir VIDEOS)/recording_$(date +%Y-%m-%d_%H.%M.%S).mp4"
	),
	{ locked = true }
)
hl.bind(
	"CTRL + ALT + R",
	hl.dsp.exec_cmd(
		"pkill --signal SIGINT wf-recorder || wf-recorder -f " ..
		"$(xdg-user-dir VIDEOS)/recording_$(date +%Y-%m-%d_%H.%M.%S).mp4"
	),
	{ locked = true }
)
hl.bind(
	"SUPER + SHIFT + ALT + R",
	hl.dsp.exec_cmd(
		"pkill --signal SIGINT wf-recorder || wf-recorder --audio -f " ..
		"$(xdg-user-dir VIDEOS)/recording_$(date +%Y-%m-%d_%H.%M.%S).mp4"
	),
	{ locked = true, description = "Utilities: Record screen (with sound)" }
)
--# Fullscreen screenshot
local grimhyprctl = "grim -o \"$(hyprctl activeworkspace -j | jq -r '.monitor')\""
hl.bind(
	"Print",
	hl.dsp.exec_cmd(grimhyprctl .. " - | wl-copy"),
	{ locked = true, description = "Utilities: Screenshot >> clipboard" }
)
hl.bind(
	"CTRL + Print",
	hl.dsp.exec_cmd(
		"mkdir -p $(xdg-user-dir PICTURES)/Screenshots && "
			.. grimhyprctl
			.. " $(xdg-user-dir PICTURES)/Screenshots/Screenshot_\"$(date '+%Y-%m-%d_%H.%M.%S')\".png"
	),
	{ locked = true, non_consuming = true, description = "Utilities: Screenshot >> clipboard & file" }
)
hl.bind("CTRL + Print", hl.dsp.exec_cmd(grimhyprctl .. " - | wl-copy"), { locked = true, non_consuming = true })
--# AI
hl.bind(
	"SUPER + SHIFT + ALT + mouse:273",
	hl.dsp.exec_cmd(hyprScripts .. "/ai/primary-buffer-query.sh"),
	{ description = "Utilities: Generate AI summary for selected text" }
)
-- (requires a running ollama model)

--##! Screen
--# Zoom
local function zoomfunction(value)
	local zoomvalue = hl.get_config("cursor:zoom_factor")
	if (zoomvalue + value) > 3.0 then
		hl.config({ cursor = { zoom_factor = 3.0 } })
	elseif (zoomvalue + value) < 1.0 then
		hl.config({ cursor = { zoom_factor = 1.0 } })
	else
		hl.config({ cursor = { zoom_factor = zoomvalue + value } })
	end
end
hl.bind("SUPER + Minus", function()
	zoomfunction(-0.3)
end, { repeating = true, description = "Screen: Zoom out" })
hl.bind("SUPER + Equal", function()
	zoomfunction(0.3)
end, { repeating = true, description = "Screen: Zoom in" })

--# Zoom with keypad
hl.bind("SUPER + code:82", function()
	zoomfunction(-0.3)
end, { repeating = true })
hl.bind("SUPER + code:86", function()
	zoomfunction(0.3)
end, { repeating = true })

--##! Media
local mediaNextCommand =
	'playerctl next || playerctl position `bc <<< "100 * $(playerctl metadata mpris:length) / 1000000 / 100"`'
hl.bind("SUPER + SHIFT + N", hl.dsp.exec_cmd(mediaNextCommand), { locked = true, description = "Media: Next track" })
hl.bind("XF86AudioNext", hl.dsp.exec_cmd(mediaNextCommand), { locked = true })
hl.bind("XF86AudioPrev", hl.dsp.exec_cmd("playerctl previous"), { locked = true })
hl.bind("SUPER + SHIFT + ALT + mouse:275", hl.dsp.exec_cmd("playerctl previous"))
hl.bind("SUPER + SHIFT + ALT + mouse:276", hl.dsp.exec_cmd(mediaNextCommand))
hl.bind(
	"SUPER + SHIFT + B",
	hl.dsp.exec_cmd("playerctl previous"),
	{ locked = true, description = "Media: Previous track" }
)
hl.bind(
	"SUPER + SHIFT + P",
	hl.dsp.exec_cmd("playerctl play-pause"),
	{ locked = true, description = "Media: Play/pause media" }
)
hl.bind("XF86AudioPlay", hl.dsp.exec_cmd("playerctl play-pause"), { locked = true })
hl.bind("XF86AudioPause", hl.dsp.exec_cmd("playerctl play-pause"), { locked = true })
hl.bind("XF86AudioMute", hl.dsp.exec_cmd("wpctl set-mute @DEFAULT_SINK@ toggle"), { locked = true })
hl.bind(
	"SUPER + SHIFT + M",
	hl.dsp.exec_cmd("wpctl set-mute @DEFAULT_SINK@ toggle"),
	{ locked = true, description = "Media: Toggle mute" }
)
hl.bind("ALT + XF86AudioMute", hl.dsp.exec_cmd("wpctl set-mute @DEFAULT_SOURCE@ toggle"), { locked = true })
hl.bind("XF86AudioMicMute", hl.dsp.exec_cmd("wpctl set-mute @DEFAULT_SOURCE@ toggle"), { locked = true })
hl.bind(
	"SUPER + ALT + M",
	hl.dsp.exec_cmd("wpctl set-mute @DEFAULT_SOURCE@ toggle"),
	{ locked = true, description = "Media: Toggle mic" }
)

--#!
--##! Window
--# Focusing
hl.bind("SUPER + mouse:272", hl.dsp.window.drag(), { mouse = true, description = "Window: Move" })
hl.bind("SUPER + mouse:274", hl.dsp.window.drag(), { mouse = true })
hl.bind("SUPER + mouse:273", hl.dsp.window.resize(), { mouse = true, description = "Window: Resize" })
--#/# bind = SUPER + ←/↑/→/↓,, -- Focus in direction
for i = 1, 4 do
	local arrowkey = { "Left", "Right", "Up", "Down" }
	local focusdir = { "l", "r", "u", "d" }
	hl.bind(
		"SUPER + " .. arrowkey[i],
		hl.dsp.focus({ direction = focusdir[i] }),
		{ description = "Window: Focus " .. arrowkey[i] }
	)
end
for i = 1, 2 do
	local arrowkey = { "BracketLeft", "BracketRight" }
	local focusdir = { "l", "r" }
	hl.bind("SUPER + " .. arrowkey[i], hl.dsp.focus({ direction = focusdir[i] }))
end
--#/# bind = SUPER + SHIFT, ←/↑/→/↓,, -- Move in direction
for i = 1, 4 do
	local arrowkey = { "Left", "Right", "Up", "Down" }
	local focusdir = { "l", "r", "u", "d" }
	hl.bind(
		"SUPER + SHIFT + " .. arrowkey[i],
		hl.dsp.window.move({ direction = focusdir[i] }),
		{ description = "Window: Move " .. arrowkey[i] }
	)
end

hl.bind("ALT + F4", function()
	hl.exec_cmd('notify-send "Wrong close keybind" "Super+Q to close. Use Alt+F4 for Windows VMs" -a Hyprland')
end, { non_consuming = true })
hl.bind("SUPER + Q", hl.dsp.window.close(), { description = "Window: Close" })
hl.bind("SUPER + SHIFT + ALT + Q", hl.dsp.exec_cmd("hyprctl kill"), { description = "Window: Forcefully zap a window" })

--# Window split ratio
--#/# binde = SUPER, ;/',, -- Adjust split ratio
hl.bind("SUPER + Semicolon", hl.dsp.layout("splitratio -0.1"), { repeating = true })
hl.bind("SUPER + Apostrophe", hl.dsp.layout("splitratio +0.1"), { repeating = true })
--# Positioning mode
hl.bind("SUPER + ALT + Space", hl.dsp.window.float({ action = "toggle" }), { description = "Window: Float/Tile" })
hl.bind(
	"SUPER + D",
	hl.dsp.window.fullscreen({ mode = "maximized", action = "toggle" }),
	{ description = "Window: Maximize" }
)
hl.bind(
	"SUPER + F",
	hl.dsp.window.fullscreen({ mode = "fullscreen", action = "toggle" }),
	{ description = "Window: Fullscreen" }
)
hl.bind(
	"SUPER + ALT + F",
	hl.dsp.window.fullscreen_state({ internal = 0, client = 3, action = "toggle" }),
	{ description = "Window: Fullscreen spoof" }
)
hl.bind("SUPER + P", hl.dsp.window.pin(), { description = "Window: Pin" })
--# Manda la ventana activa al "segundo plano" (aparece en el módulo bgapps de waybar)
hl.bind(
	"SUPER + H",
	hl.dsp.exec_cmd("$HOME/.config/hypr/hyprland/scripts/bgapps.sh hide"),
	{ description = "Window: Minimize / send to background" }
)

--#/# bind = SUPER+ALT, Hash,, -- Send to workspace -- (1, 2, 3,...)
for i = 1, 10 do
	hl.bind("SUPER + ALT + " .. (i % 10), function()
		hl.dispatch(hl.dsp.window.move({ workspace = workspace_in_group(i), follow = false }))
	end, { description = "Window: Send to workspace " .. i })
end
--# We also use raw keycodes because some keyboard layouts register number keys as different chars. The codes can be verified with `wev`
for i = 1, 10 do
	local numberkey = { 10, 11, 12, 13, 14, 15, 16, 17, 18, 19 }
	hl.bind("SUPER + ALT + code:" .. numberkey[i], function()
		hl.dispatch(hl.dsp.window.move({ workspace = workspace_in_group(i), follow = false }))
	end)
end
--# keypad numbers
for i = 1, 10 do
	local numpadkey = { 87, 88, 89, 83, 84, 85, 79, 80, 81, 90 }
	hl.bind("SUPER + ALT + code:" .. numpadkey[i], function()
		hl.dispatch(hl.dsp.window.move({ workspace = workspace_in_group(i), follow = false }))
	end)
end

--# #/# bind = SUPER+SHIFT, Scroll ↑/↓,, -- Send to workspace left/right
for i = 1, 4 do
	local key = { "SUPER + SHIFT + mouse_", "SUPER + ALT + mouse_" }
	local keycombos = { key[1] .. "down", key[1] .. "up", key[2] .. "down", key[2] .. "up" }
	local prefix = { "r-", "r+", "r-", "r+" }
	hl.bind(keycombos[i], hl.dsp.window.move({ workspace = prefix[i] .. "1" }))
end

--#/# bind = SUPER+SHIFT, Page_↑/↓,, -- Send to workspace left/right
for i = 1, 2 do
	local keydirs = { "Up", "Down" }
	local prefix = { "r-", "r+" }
	local descdir = { "left", "right" }
	hl.bind(
		"SUPER + SHIFT + Page_" .. keydirs[i],
		hl.dsp.window.move({ workspace = prefix[i] .. "1" }),
		{ description = "Window: Send to workspace " .. descdir[i] }
	)
end
for i = 1, 4 do
	local key = { "SUPER + ALT + Page_", "CTRL + SUPER + SHIFT + " }
	local keycombos = { key[1] .. "down", key[1] .. "up", key[2] .. "Right", key[2] .. "Left" }
	local prefix = { "r+", "r-", "r+", "r-" }
	hl.bind(keycombos[i], hl.dsp.window.move({ workspace = prefix[i] .. "1" })) -- # [hidden]
end

hl.bind(
	"SUPER + ALT + S",
	hl.dsp.window.move({ workspace = "special:special", follow = false }),
	{ description = "Window: Send to scratchpad" }
)
hl.bind("CTRL + SUPER + S", hl.dsp.workspace.toggle_special("special"))

--##! Workspace
--# Switching
--#/# bind = SUPER, Hash,, -- Focus workspace -- (1, 2, 3,...)
for i = 1, 10 do
	hl.bind("SUPER + " .. (i % 10), function()
		hl.dispatch(hl.dsp.focus({ workspace = workspace_in_group(i) }))
	end, { description = "Workspace: Focus " .. i })
end
--# We also use raw keycodes because some keyboard layouts register number keys as different chars. The codes can be verified with `wev`
for i = 1, 10 do
	local numberkey = { 10, 11, 12, 13, 14, 15, 16, 17, 18, 19 }
	hl.bind("SUPER + code:" .. numberkey[i], function()
		hl.dispatch(hl.dsp.focus({ workspace = workspace_in_group(i) }))
	end)
end
--# keypad numbers
for i = 1, 10 do
	local numpadkey = { 87, 88, 89, 83, 84, 85, 79, 80, 81, 90 }
	hl.bind("SUPER + code:" .. numpadkey[i], function()
		hl.dispatch(hl.dsp.focus({ workspace = workspace_in_group(i) }))
	end)
end

--#/# bind = CTRL+SUPER, ←/→,, -- Focus left/right
--#/# bind = CTRL+SUPER+ALT, ←/→,, -- # [hidden] Focus busy left/right
for i = 1, 2 do
	local keys = { "Left", "Right" }
	local prefix = { "r-", "r+" }
	local descdir = { "left", "right" }
	hl.bind(
		"CTRL + SUPER + " .. keys[i],
		hl.dsp.focus({ workspace = prefix[i] .. "1" }),
		{ description = "Workspace: Focus " .. descdir[i] }
	)
end
for i = 1, 2 do
	local keys = { "Left", "Right" }
	local prefix = { "m-", "m+" }
	hl.bind("CTRL + SUPER + ALT + " .. keys[i], hl.dsp.focus({ workspace = prefix[i] .. "1" }))
end
--#/# bind = SUPER, Page_↑/↓,, -- Focus left/right
for i = 1, 4 do
	local key = { "SUPER + Page_Down", "SUPER + Page_Up" }
	local keycombos = { key[1], key[2], "CTRL + " .. key[1], "CTRL + " .. key[2] }
	local prefix = { "r+", "r-", "r+", "r-" }
	hl.bind(keycombos[i], hl.dsp.focus({ workspace = prefix[i] .. "1" }))
end
--#/# bind = SUPER, Scroll ↑/↓,, -- Focus left/right
for i = 1, 4 do
	local key = { "SUPER + mouse_up", "SUPER + mouse_down" }
	local keycombos = { key[1], key[2], "CTRL + " .. key[1], "CTRL + " .. key[2] }
	local prefix = { "+", "-", "r+", "r-" }
	hl.bind(keycombos[i], hl.dsp.focus({ workspace = prefix[i] .. "1" }))
end
--## Special
hl.bind("SUPER + S", hl.dsp.workspace.toggle_special("special"), { description = "Workspace: Toggle scratchpad" })
hl.bind("SUPER + mouse:275", hl.dsp.workspace.toggle_special("special"))
for i = 1, 4 do
	local key = { "BracketLeft", "BracketRight", "Up", "Down" }
	local prefix = { "-1", "+1", "r-5", "r+5" }
	hl.bind("CTRL + SUPER + " .. key[i], hl.dsp.focus({ workspace = prefix[i] }))
end

--##! Virtual machines
hl.define_submap("virtual-machine", function()
	hl.bind("SUPER + ALT + F1", function()
		local currentsubmap = hl.get_current_submap()
		if currentsubmap == "virtual-machine" then
			hl.dispatch(
				hl.dsp.exec_cmd("notify-send 'Exited Virtual Machine submap' 'Keybinds re-enabled' -a 'Hyprland'")
			)
			hl.dispatch(hl.dsp.submap("reset"))
		elseif currentsubmap == "" then
			hl.dispatch(
				hl.dsp.exec_cmd(
					"notify-send 'Entered Virtual Machine submap' 'Keybinds disabled. hit SUPER+ALT+F1 to escape' -a 'Hyprland'"
				)
			)
			hl.dispatch(hl.dsp.submap("virtual-machine"))
		end
	end, { submap_universal = true })
end)

--#!
--# Testing
hl.bind(
	"SUPER + ALT + F11",
	hl.dsp.exec_cmd(
		'bash -c \'RANDOM_IMAGE=$(find ~/Pictures -type f | shuf -n 1); ACTION=$(notify-send "Test notification with body image" "This notification should contain your user account <b>image</b> and <a href=\\"https://discord.com/app\\">Discord</a> <b>icon</b>. Oh and here is a random image in your Pictures folder: <img src=\\"$RANDOM_IMAGE\\" alt=\\"Testing image\\"/>" -a "Hyprland" -p -h "string:image-path:/var/lib/AccountsService/icons/$USER" -t 6000 -i "discord" -A "openImage=Profile image" -A "action2=Open the random image" -A "action3=Useless button"); [[ $ACTION == *openImage ]] && xdg-open "/var/lib/AccountsService/icons/$USER"; [[ $ACTION == *action2 ]] && xdg-open "$RANDOM_IMAGE"\''
	)
) -- # [hidden]
hl.bind(
	"SUPER + ALT + F12",
	hl.dsp.exec_cmd(
		'bash -c \'RANDOM_IMAGE=$(find ~/Pictures -type f | shuf -n 1); ACTION=$(notify-send "Test notification" "This notification should contain a random image in your <b>Pictures</b> folder and <a href=\\"https://discord.com/app\\">Discord</a> <b>icon</b>.\n<i>Flick right to dismiss!</i>" -a "Discord (fake)" -p -h "string:image-path:$RANDOM_IMAGE" -t 6000 -i "discord" -A "openImage=Profile image" -A "action2=Useless button"); [[ $ACTION == *openImage ]] && xdg-open "/var/lib/AccountsService/icons/$USER"\''
	)
) -- # [hidden]
hl.bind(
	"SUPER + ALT + Equal",
	hl.dsp.exec_cmd("notify-send 'Urgent notification' 'Ah hell no' -u critical -a 'Hyprland keybind'")
) -- # [hidden]

--##! Session
hl.bind("SUPER + L", hl.dsp.exec_cmd("loginctl lock-session"), { description = "Session: Lock" })
hl.bind(
	"SUPER + SHIFT + L",
	hl.dsp.exec_cmd("systemctl suspend || loginctl suspend"),
	{ locked = true, description = "Session: Sleep" }
) -- Sleep
-- hl.bind("switch:on:Lid Switch", hl.dsp.exec_cmd("systemctl suspend || loginctl suspend"), {locked = true} ) -- # [hidden] Suspend when laptop lid is closed, uncomment if for whatever reason it's not the default behavior

hl.bind(
	"CTRL + SHIFT + ALT + SUPER + Delete",
	hl.dsp.exec_cmd("systemctl poweroff || loginctl poweroff"),
	{ description = "Session: Shut down" }
) -- # [hidden] Power off

-- Segundo monitor virtual para streaming con Sunshine/Moonlight (pantalla
-- extendida, no espejo). Ver hyprland/scripts/HeadlessDisplay-On.sh
hl.bind(
	"SUPER + SHIFT + ALT + M",
	hl.dsp.exec_cmd(hyprScripts .. "/HeadlessDisplay-On.sh"),
	{ description = "Session: Create virtual monitor (streaming)" }
)
hl.bind(
	"SUPER + CTRL + ALT + M",
	hl.dsp.exec_cmd(hyprScripts .. "/HeadlessDisplay-Off.sh"),
	{ description = "Session: Remove virtual monitor" }
)

--##! Apps
hl.bind("SUPER + Return", hl.dsp.exec_cmd(terminal), { description = "App: Terminal" })
hl.bind("SUPER + T", hl.dsp.exec_cmd(terminal))
hl.bind("CTRL + ALT + T", hl.dsp.exec_cmd(terminal))
hl.bind("SUPER + E", hl.dsp.exec_cmd(fileManager), { description = "App: File manager" })
hl.bind("SUPER + W", hl.dsp.exec_cmd(browser), { description = "App: Browser" })
hl.bind("SUPER + C", hl.dsp.exec_cmd(codeEditor), { description = "App: Code editor" })
hl.bind("CTRL + SUPER + SHIFT + ALT + W", hl.dsp.exec_cmd(officeSoftware), { description = "App: Office software" })
hl.bind("SUPER + X", hl.dsp.exec_cmd(textEditor), { description = "App: Text editor" })
hl.bind("CTRL + SUPER + V", hl.dsp.exec_cmd(volumeMixer), { description = "App: Volume mixer" })
hl.bind("SUPER + I", hl.dsp.exec_cmd(settingsApp), { description = "App: Settings app" })
hl.bind("CTRL + SHIFT + Escape", hl.dsp.exec_cmd(taskManager), { description = "App: Task manager" })

--# Cursed stuff
--## Make window not amogus large
hl.bind("CTRL + SUPER + Backslash", hl.dsp.window.resize({ x = 640, y = 480, "exact" }))
